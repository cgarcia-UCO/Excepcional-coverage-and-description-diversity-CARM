#!/bin/bash

for i in $( ls ); do

    if [ -L $i ]; then
        data=$( ls -l $i )
        link_name=$( echo $data | tr -s ' ' | cut -d' ' -f9 );
        file_name=$( echo $data | tr -s ' ' | cut -d' ' -f11 );
        rm $link_name
        cp -r $file_name $link_name
    fi
done
